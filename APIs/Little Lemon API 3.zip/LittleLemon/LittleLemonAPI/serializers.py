from rest_framework import serializers
from .models import MenuItem, Category, Order, Cart
from decimal import Decimal

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'title']


class MenuItemSerializer(serializers.ModelSerializer):
    #stock = serializers.IntegerField(source='inventory')
    price_after_tax = serializers.SerializerMethodField(method_name='calculate_tax')
    category_id = serializers.IntegerField(write_only=True)
    category = CategorySerializer(read_only=True)
    class Meta:
        model = MenuItem
        fields = ['id', 'title','price','inventory','price_after_tax','category','category_id']
        
    def calculate_tax(self, single_item:MenuItem):
        return round(single_item.price*Decimal(1.1),2)

class CartSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cart
        fields = ['id','menuitem','quantity']

class OrderSerializer(serializers.ModelSerializer):
    all_items = serializers.SerializerMethodField(method_name='get_items')
    total_price = serializers.SerializerMethodField(method_name='get_total')
    total_tax = serializers.SerializerMethodField(method_name='total_after_tax')
    class Meta:
        model = Order
        fields = ['id','username','all_items', 'total_price','total_tax','is_delivered']
        
    def get_items(self, Order):
        return Order.items.all()
    
    def get_total(self, Order):
        return sum([item.price * item.quantity for item in Order.items.all()])
    
    def total_after_tax(self):
        return round(self.total_price*Decimal(1.1),2)