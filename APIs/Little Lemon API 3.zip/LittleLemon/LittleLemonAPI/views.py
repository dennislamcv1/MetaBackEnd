from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import MenuItem, Category, Cart, Order
from .serializers import MenuItemSerializer, CategorySerializer, CartSerializer, OrderSerializer
from django.shortcuts import get_object_or_404
from rest_framework import status
# pagination
from django.core.paginator import Paginator, EmptyPage
# authentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework.decorators import permission_classes
from django.contrib.auth.models import User, Group
# throttling
from rest_framework.throttling import AnonRateThrottle
from rest_framework.decorators import throttle_classes
from rest_framework.throttling import UserRateThrottle

# class-based view 
class CategoriesView(generics.ListCreateAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated]
#
#class MenuItemsView(generics.ListCreateAPIView):
#    queryset = MenuItem.objects.all()
#    serializer_class = MenuItemSerializer
#    authentication_classes = [TokenAuthentication]
#    permission_classes = [IsAuthenticated]
#    ordering_fields = ['price','inventory','category']
#    filterset_fields = ['price','inventory','category']
#    search_fields = ['title']
#
#class SingleMenuItemView(generics.RetrieveUpdateDestroyAPIView):
#    queryset = MenuItem.objects.all()
#    serializer_class = MenuItemSerializer
#    authentication_classes = [TokenAuthentication]
#    permission_classes = [IsAuthenticated]
#    
#class CartView(generics.ListCreateAPIView, generics.RetrieveUpdateDestroyAPIView):
#    queryset = Cart.objects.all()
#    serializer_class = CartSerializer
#    authentication_classes = [TokenAuthentication]
#    permission_classes = [IsAuthenticated]
#    
#    def get(self, request, format=None):
#        content = {
#            'user':str(request.user),
#            #'auth':str(request.auth),
#            'cart':self.queryset.all()
#        }
#        return Response(self.queryset.all())
#    
#    def post(self, request, format=None):
#        content = {
#            'user':str(request.user),
#            'auth':str(request.auth),
#        }
#        return Response(content)
#    
#    def delete(self, request, format=None):
#        content = {
#            'user':str(request.user),
#            'auth':str(request.auth),
#        }
#        return Response(content)
#
#class OrdersView(generics.ListCreateAPIView):
#    queryset = Order.objects.all()
#    serializer_class = OrderSerializer
#    authentication_classes = [TokenAuthentication]
#    permission_classes = [IsAuthenticated]
#    
#    def get(self, request, format=None):
#        content = {
#            'user':str(request.user),
#            #'auth':str(request.auth),
#            'order':self.queryset.all()
#        }
#        return Response(content)
#    
#    def post(self, request, format=None):
#        content = {
#            'user':str(request.user),
#            'auth':str(request.auth),
#        }
#        return Response(content)
#    
#    def delete(self, request, format=None):
#        content = {
#            'user':str(request.user),
#            'auth':str(request.auth),
#        }
#        return Response(content)
#
#class SingleOrderView(generics.RetrieveUpdateDestroyAPIView):
#    queryset = Order.objects.all()
#    serializer_class = OrderSerializer
#    authentication_classes = [TokenAuthentication]
#    permission_classes = [IsAuthenticated]
#    ordering_fields = ['title','price']
#    filterset_fields = ['title','price']
#    search_fields = ['title']

# function-based view
@api_view(['GET','POST'])
def menu_items(request):
    if request.method == 'GET':
        items = MenuItem.objects.select_related('category').all()
        # filtering
        category_name = request.query_params.get('category')        
        to_price = request.query_params.get('to_price')
        if category_name:
            items = items.filter(category__title=category_name)     # dunder title
        if to_price:
            items = items.filter(price__lte=to_price)
        # searching
        search = request.query_params.get('search')                 
        if search:
            items = items.filter(title__istartwith=search)
        # ordering
        ordering = request.query_params.get('ordering')  
        if ordering:
            ordering_fields = ordering.split(",")
            items = items.order_by(*ordering_fields)
        # pagination
        perpage = request.query_params.get('perpage',default=2)     
        page = request.query_paramsget('page',default=1)
        paginator = Paginator(items, per_page=perpage)
        try:
            items = paginator.page(number=page)
        except EmptyPage:
            items = []
        serialized_item = MenuItemSerializer(items, many=True)
        return Response(serialized_item.data)
    elif request.method == 'POST' and request.user.groups.filter(name='Manager').exists():
        serialized_item = MenuItemSerializer(data=request.data)
        serialized_item.is_valid(raise_exception=True)
        serialized_item.save()
        return Response(serialized_item.data, status.HTTP_201_CREATED)
    else:
        return Response({"message":"You are not authorized"}, status.HTTP_403_FORBIDDEN)
            
@api_view(['GET','PUT','PATCH','DELETE'])
def single_item(request,id):
    item = get_object_or_404(MenuItem,pk=id)
    if request.method == 'GET':
        serialized_item = MenuItemSerializer(item)
        return Response(serialized_item.data, 201)
    elif request.method == 'POST':
        if request.user.groups.filter(name='Manager').exists():
            serialized_item = MenuItemSerializer(data=request.data)
            serialized_item.is_valid(raise_exception=True)
            serialized_item.save()
            return Response(serialized_item.data, status.HTTP_201_CREATED)
        else:
            return({'message':'You are not authorized'}, status.HTTP_403_FORBIDDEN)
    elif request.method == 'PUT' or request.method == 'PATCH':
        if request.user.groups.filter(name='Manager').exists():
            serialized_item = MenuItemSerializer(data=request.data)
            serialized_item.is_valid(raise_exception=True)
            serialized_item.update()
            return Response(serialized_item.data)
        else:
            return({'message':'You are not authorized'}, status.HTTP_403_FORBIDDEN)
    elif request.method == 'DELETE':
        if request.user.groups.filter(name='Manager').exists():
            return Response(item.delete(), status.HTTP_200_OK)
        else:
            return({'message':'You are not authorized'}, status.HTTP_403_FORBIDDEN)

@api_view(['GET','POST', 'DELETE'])
@permission_classes([IsAuthenticated])
def managers(request, id):
    user = get_object_or_404(User, pk=id)                       # user with id
    manager_group = Group.objects.get(name='Manager')           # all managers
    if request.user.groups.filter(name='Manager').exists():
        if request.method == 'GET':
            return Response(manager_group)  
        elif request.method == 'POST':         
            return Response(manager_group.user_set.add(user), status.HTTP_201_CREATED)   # add user to manager group
        elif request.method == 'DELETE':
            return Response(manager_group.user_set.delete(user), status.HTTP_200_OK)      # remove user from manager group
    else:
        return Response({"message":"You are not authorized"}, status.HTTP_403_FORBIDDEN)

@api_view(['GET','POST', 'DELETE'])
@permission_classes([IsAuthenticated])
def delivery_crew(request, id):
    user = get_object_or_404(User, pk=id)                       # user with id
    delcrew_group = Group.objects.get(name='DeliveryCrew')           # all delivery crews
    if request.user.groups.filter(name='DeliveryCrew').exists():
        if request.method == 'GET':
            return Response(delcrew_group)  
        elif request.method == 'POST':         
            return Response(delcrew_group.user_set.add(user), status.HTTP_201_CREATED)   # add user to delivery crew group
        elif request.method == 'DELETE':
            return Response(delcrew_group.user_set.delete(user), status.HTTP_200_OK)      # remove user from delivery group
    else:
        return Response({"message":"You are not authorized"}, status.HTTP_403_FORBIDDEN)
    
@api_view(['GET', 'POST', 'DELETE'])
def cart(request):
    if not request.user.groups.filter(name='Manager').exists() and not request.user.groups.filter(name='DeliveryCrew').exists():
        if request.method == 'GET':
            items = Cart.objects.all()
            serialized_item = CartSerializer(items, many=True)
            return Response(serialized_item.data)
        elif request.method == 'POST':
            serialized_item = CartSerializer(data=request.data)
            serialized_item.is_valid(raise_exception=True)
            serialized_item.save()
            return Response(serialized_item.data, status.HTTP_201_CREATED)
        elif request.method == 'DELETE':
            return Response(serialized_item.datat.delete(), status.HTTP_200_OK) 

@api_view(['GET','POST'])
def orders(request):
    if request.method == 'GET':
        items = Order.objects.all()
        # filtering
        ref = request.query_params.get('order_ref')        
        to_total = request.query_params.get('to_total')
        if ref:
            items = items.filter(category__title=ref)
        if to_total:
            items = items.filter(price__lte=to_total)
        # searching
        search = request.query_params.get('search')                 
        if search:
            items = items.filter(title__istartwith=search)
        # ordering
        ordering = request.query_params.get('ordering')  
        if ordering:
            ordering_fields = ordering.split(",")
            items = items.order_by(*ordering_fields)
        # pagination
        perpage = request.query_params.get('perpage',default=2)     
        page = request.query_paramsget('page',default=1)
        paginator = Paginator(items, per_page=perpage)
        try:
            items = paginator.page(number=page)
        except EmptyPage:
            items = []
        serialized_item = OrderSerializer(items, many=True)
        return Response(serialized_item.data)
    elif request.method == 'POST' and request.user.groups.filter(name='Manager').exists():
        serialized_item = OrderSerializer(data=request.data)
        serialized_item.is_valid(raise_exception=True)
        serialized_item.save()
        return Response(serialized_item.data, status.HTTP_201_CREATED)
    else:
        return Response({"message":"You are not authorized"}, status.HTTP_403_FORBIDDEN)
            
@api_view(['GET','PUT','PATCH','DELETE'])
def single_order(request,id):
    item = get_object_or_404(Order,pk=id)
    if request.method == 'GET':
        serialized_item = OrderSerializer(item)
        return Response(serialized_item.data, 201)
    elif request.method == 'POST':
        if request.user.groups.filter(name='Manager').exists():
            serialized_item = OrderSerializer(data=request.data)
            serialized_item.is_valid(raise_exception=True)
            serialized_item.save()
            return Response(serialized_item.data, status.HTTP_201_CREATED)
        else:
            return({'message':'You are not authorized'}, status.HTTP_403_FORBIDDEN)
    elif request.method == 'PUT' or request.method == 'PATCH':
        if request.user.groups.filter(name='Manager').exists():
            serialized_item = OrderSerializer(data=request.data)
            serialized_item.is_valid(raise_exception=True)
            serialized_item.update()
            return Response(serialized_item.data)
        else:
            return({'message':'You are not authorized'}, status.HTTP_403_FORBIDDEN)
    if request.user.groups.filter(name='Manager').exists():
        if request.method == 'DELETE':
            return Response(item.delete(), status.HTTP_200_OK)
        else:
            return({'message':'You are not authorized'}, status.HTTP_403_FORBIDDEN)

# throttling
@api_view()
@throttle_classes([AnonRateThrottle])
def throttle_check(request):
    return Response({"message":"successful!"})

@api_view()
@permission_classes([IsAuthenticated])
@throttle_classes([UserRateThrottle])
def throttle_check_auth(request):
    return Response({"message":"message for authenticated user only"})