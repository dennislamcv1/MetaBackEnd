from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Category(models.Model):
    slug = models.SlugField()
    title = models.CharField(max_length=255)
    
    def __str__(self)->str:
        return self.title

class MenuItem(models.Model):
    title = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=6, decimal_places=2 ,null=False)
    inventory = models.SmallIntegerField()
    category = models.ForeignKey(Category, on_delete=models.PROTECT, default=1)

    def __str__(self)->str:
        return self.title


class Cart(models.Model):
    menuitem = models.OneToOneField(MenuItem, on_delete=models.CASCADE)
    quantity = models.SmallIntegerField(default=1)
    
    def __str__(self)->str:
        return self.menuitem.title + ': ' + str(self.quantity)


class Order(models.Model):
    username = models.CharField(max_length=255)
    items = models.ManyToManyField(Cart)
    is_delivered = models.BooleanField(default=False)

    def __str__(self)->str:
        if self.is_delivered:
            return f'{self.id} is delivered' 
        return f"{self.username}'s order No.:{self.id} is not delivered"
    